<?php

namespace Database\Seeders;

use App\Models\City;
use App\Models\Province;
use App\Models\Provincee;
use Illuminate\Database\Seeder;
use Kavist\RajaOngkir\Facades\RajaOngkir;

class LocationsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $daftarprovinsi = RajaOngkir::provinsi()->all();
        foreach($daftarprovinsi as $provinsirow) {
            Province::create([
                'province_id' => $provinsirow['province_id'],
                'title' =>$provinsirow['province']
            ]);
            $daftarkota = RajaOngkir::kota()->dariProvinsi($provinsirow['province_id'])->get();
            foreach($daftarkota as $cityrow)
     {
                City::create([
                'province_id' => $cityrow['province_id'],
                'city_id' => $cityrow['city_id'],
                'title' => $cityrow['city_name'],
            ]);
     }
        }
    }
}
