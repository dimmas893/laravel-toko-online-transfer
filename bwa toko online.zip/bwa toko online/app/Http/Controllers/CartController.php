<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Courier;
use App\Models\Province;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Kavist\RajaOngkir\Facades\RajaOngkir;

class CartController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $idid = Auth::user()->id;
        $user = Auth::user();
        $carts = Cart::with(['product.galleries', 'user'])->where('users_id', $idid)->get();
        $couriers = Courier::pluck('title', 'code');
        $provinces = Province::pluck('name', 'province_id'); 
        return view('pages.cart',[
            'carts' => $carts,
            'couriers' => $couriers,
            'provinces' => $provinces,
            'user' => $user,
        ]);
    }



    // public function getCities($id)
    // {
    //     return view('pages.ambil-kabupaten');
    // }

    //     public function tabel()
    // {
    //     return view('pages.tabel-ongkir');
    // }


    public function checkOngkir(Request $request)
    {
    $cost =  RajaOngkir::ongkosKirim([
                'origin' => 113, //ID kota / Kabupaten asal/ 113 adalah kode kota Bekasi
                'destination' => $request->city_destination, //Id Kota //kabupaten tujuan
                
                'originType' => "city",
                'weight' => 30, // berat barang dalam gram sample 100
                'courier' => $request->courier // kode kurir pengiriman: ['jne', 'tiki', 'pos'] untuk starter
            ])->get();

            return response()->json([
                'success' => true,
                'message' => 'List Data Cost All Courir: ' . $request->courier,
                'data'    => $cost
            ]);


    }

    public function delete(Request $request, $id)
    {
        $cart = Cart::findOrFail($id);

        $cart->delete();

        return redirect()->route('cart');
    }
    
    public function success()
    {
        return view('pages.success');
    }
}
